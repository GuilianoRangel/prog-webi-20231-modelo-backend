package br.ueg.prog.webi.api.model;

public abstract class BaseEntidade<PK_TYPE> implements IEntidade<PK_TYPE>{

}
