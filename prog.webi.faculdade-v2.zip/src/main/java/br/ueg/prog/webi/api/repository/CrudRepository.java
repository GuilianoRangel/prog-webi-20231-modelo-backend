package br.ueg.prog.webi.api.repository;

public class CrudRepository {
}
