package br.ueg.prog.webi.faculdade.dto;

import lombok.Data;

public @Data class AlunoListaDTO {
    private Long id;
    private String primeiroNome;
    private String segundoNome;
}
