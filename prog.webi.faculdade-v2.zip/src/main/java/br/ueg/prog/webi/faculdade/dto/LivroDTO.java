package br.ueg.prog.webi.faculdade.dto;

import br.ueg.prog.webi.faculdade.model.enums.StatusAtivoInativo;
import br.ueg.prog.webi.faculdade.model.enums.converter.StatusAtivoInativoConverter;
import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.Column;
import jakarta.persistence.Convert;
import lombok.Data;

import java.time.LocalDate;

public @Data class LivroDTO {
    private Long id;

    private String titulo;

    @JsonFormat(shape = JsonFormat.Shape.STRING)
    private LocalDate dataPublicacao;

    private TipoDTO tipo;

    private StatusAtivoInativo status;
}
