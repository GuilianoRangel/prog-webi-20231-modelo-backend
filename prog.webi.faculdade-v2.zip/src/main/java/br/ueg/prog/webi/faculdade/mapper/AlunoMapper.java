package br.ueg.prog.webi.faculdade.mapper;

import br.ueg.prog.webi.api.mapper.BaseMapper;
import br.ueg.prog.webi.faculdade.dto.AlunoDTO;
import br.ueg.prog.webi.faculdade.dto.AlunoDadosAlteravelDTO;
import br.ueg.prog.webi.faculdade.dto.AlunoListaDTO;
import br.ueg.prog.webi.faculdade.model.Aluno;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AlunoMapper {

    /**
     * Converte a Entidade {@link Aluno} em {@link AlunoListaDTO}
     * @param aluno
     * @return
     */
    public AlunoListaDTO toDTO(Aluno aluno);

    public List<AlunoListaDTO> toDTO(List<Aluno> alunos);

    public AlunoDadosAlteravelDTO toAlunoIncluirDTO(Aluno aluno);

    public Aluno toModelo(AlunoDadosAlteravelDTO aluno);

    public AlunoDTO toAlunoDTO(Aluno aluno);

    public Aluno toModelo(AlunoDTO aluno);

}
