package br.ueg.prog.webi.faculdade.model;


import br.ueg.prog.webi.api.model.IEntidade;
import br.ueg.prog.webi.faculdade.model.enums.StatusAtivoInativo;
import br.ueg.prog.webi.faculdade.model.enums.converter.StatusAtivoInativoConverter;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDate;

import static jakarta.persistence.GenerationType.SEQUENCE;

@Data
@Entity
@Table(name = "TBL_TIPO",
        uniqueConstraints = {
                @UniqueConstraint(name= Tipo.UK_TIPO_NOME, columnNames = "nome" )
        }
)
public class Tipo implements IEntidade<Long> {
    public static final String UK_TIPO_NOME = "uk_tipo_nome";
    @SequenceGenerator(
            name="a_gerador_sequence",
            sequenceName = "tipo_sequence",
            allocationSize = 1
    )
    @GeneratedValue(
            strategy = SEQUENCE,
            generator = "a_gerador_sequence"
    )
    @Id
    @Column(name = "id")
    private Long id;

    @Column(name = "nome", length = 200, nullable = false)
    private String nome;

    @Column(name = "data_criacao")
    private LocalDate dataCriacao;

    @Convert(converter = StatusAtivoInativoConverter.class)
    @Column(name = "status_tipo", length = 1)
    private StatusAtivoInativo status;

    @Override
    public String getTabelaNome() {
        return "Tipo";
    }
}