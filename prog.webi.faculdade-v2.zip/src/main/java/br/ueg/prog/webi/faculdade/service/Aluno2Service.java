package br.ueg.prog.webi.faculdade.service;

import br.ueg.prog.webi.api.service.CrudService;
import br.ueg.prog.webi.faculdade.model.Aluno;

public interface Aluno2Service extends CrudService<Aluno, Long> {

}
