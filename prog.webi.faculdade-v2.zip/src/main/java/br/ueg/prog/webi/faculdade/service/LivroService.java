package br.ueg.prog.webi.faculdade.service;

import br.ueg.prog.webi.api.service.CrudService;
import br.ueg.prog.webi.faculdade.model.Livro;

public interface LivroService
        extends CrudService<Livro, Long> {

}
